simplewall 3.9.2-fork.2 - Windows x64

Packets log now lists apps by their latest blocked activity. Select an app to inspect its history. Selection stays on that app as new activity reorders the list.

History survives restart. Group repeats switches between grouped traffic and the original events. Use Retention to adjust limits globally or for an app. Defaults: 200,000 events/app, seven days, 1 GiB total. Oldest events expire first; the global budget can evict history across apps. Lost/evicted event counts and retained ranges are shown.

History uses packet-history.db in the existing profile directory. Close simplewall gracefully before copying the database for backup. The packet-log toggle controls capture; allowed connections still follow Settings > Exclude.

This is an unsigned custom fork build. Source and validation: https://github.com/Mainkill1/simplewall/releases/tag/v3.9.2-fork.2
